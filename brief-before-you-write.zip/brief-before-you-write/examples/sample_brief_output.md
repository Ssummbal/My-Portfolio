# Sample Output

This file shows two things: (1) real output captured from running `test_pipeline.py` against three short sample "articles" about sourdough baking, using the no-API-key extractive fallback, and (2) an illustrative mock-up of what the same question looks like in LLM-synthesis mode (with `ANTHROPIC_API_KEY` set), so you can see the intended end-state format.

The three toy sources used below:
- **Article A** — a beginner's guide to sourdough (starter, bulk fermentation, shaping, baking)
- **Article B** — why sourdough fails to rise (starter activity, proofing, temperature)
- **Article C** — sourdough baking equipment (Dutch oven, bench scraper, scale, lame)

---

## 1. Real output — extractive fallback mode (no API key)

**Question:** *"What tools do these articles recommend for baking sourdough?"*

```
(No ANTHROPIC_API_KEY set -- showing the most relevant raw excerpts instead of a generated synthesis.)

(Source 1: Article C: Sourdough Baking Equipment Guide, relevance 0.16)
A Dutch oven is the most commonly recommended baking vessel because it traps steam,
producing a crackly crust. A bench scraper helps handle sticky dough during shaping.
A kitchen scale ensures accurate flour and water ratios, which is critical for
hydration consistency. A bread lame or sharp razor is used for scoring the loaf
before baking to control how it...

(Source 2: Article A: Beginner's Guide to Sourdough, relevance 0.10)
Sourdough bread relies on a natural starter instead of commercial yeast. To make a
starter, mix equal parts flour and water and let it ferment for five to seven days,
feeding it daily...
```

Note: in fallback mode, nothing is synthesized or paraphrased — you're seeing the raw retrieved excerpts, ranked by relevance. This mode has zero hallucination risk by construction, since no generation step happens at all. It trades that safety for fluency: the output is a set of excerpts, not a polished answer.

---

## 2. Illustrative example — LLM synthesis mode (with API key set)

*The excerpt below is a hand-written illustration of the intended output format when `ANTHROPIC_API_KEY` is set, not a captured model run. It shows the citation style the prompt in `query.py` is designed to produce.*

**Question:** *"What tools do these articles recommend for baking sourdough?"*

> The articles consistently recommend a Dutch oven as the primary baking vessel, since it traps steam and produces a crisp crust (Source 1). A kitchen scale is also recommended across sources for accurate flour-to-water ratios, described as critical for consistent hydration (Source 1). For handling the dough itself, a bench scraper is suggested for managing sticky dough during shaping, and a bread lame or sharp razor is used for scoring the loaf before it goes into the oven (Source 1).
>
> Notably, only Source 1 (the equipment-focused article) discusses tools in detail — Sources 2 and 3 focus on technique and troubleshooting rather than equipment, which could be a content gap worth addressing if your target keyword has any equipment-related search intent.

**Question (refusal case):** *"What's the best flour brand for sourdough?"*

> None of the provided source articles mention specific flour brands. They discuss flour-to-water ratios and hydration (Source 1), but not brand recommendations. This isn't something I can answer from your current sources — you'd need to add a source that specifically covers flour brand comparisons.

---

## What this demonstrates

- **Citation discipline:** every claim in the synthesized example points to a specific source, matching the requirement in `decision-rule.md`.
- **Honest refusal:** the flour-brand question isn't forced into an answer just because it's topically adjacent — the system says plainly that it isn't covered.
- **Fallback safety net:** even without any API key or cost, the tool is still useful and still grounded, just less polished.
