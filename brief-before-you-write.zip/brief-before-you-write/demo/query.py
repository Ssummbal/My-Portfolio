"""
query.py

The generation half of the RAG pipeline. Takes a question, retrieves
relevant chunks via ingest.VectorIndex, and produces a grounded answer
with inline citations -- or an explicit refusal if the sources don't
cover the question.

This is the file that encodes the core product decision from the PRD:
the system must never answer from general knowledge. See decision-rule.md
for the full reasoning.
"""

from __future__ import annotations

import os
from ingest import VectorIndex

REFUSAL_MESSAGE = (
    "I couldn't find anything in your source articles that addresses this. "
    "Try rephrasing the question, or add a source article that's more likely to cover it."
)


def build_grounded_prompt(question: str, retrieved: list[tuple]) -> str:
    """Build a prompt that constrains the model to only use retrieved chunks."""
    context_blocks = []
    for i, (chunk, score) in enumerate(retrieved, start=1):
        context_blocks.append(f"[Source {i}: {chunk.source_title}]\n{chunk.text}")
    context = "\n\n".join(context_blocks)

    return f"""You are helping a content writer build a brief from competitor articles.

Answer the question using ONLY the source excerpts below. Do not use any outside
knowledge, even if you know more about the topic. For every claim you make, cite
which source it came from, like this: (Source 2).

If the excerpts don't actually contain enough information to answer the question,
say so plainly instead of guessing.

SOURCE EXCERPTS:
{context}

QUESTION: {question}

ANSWER (with inline source citations):"""


def _extractive_fallback(question: str, retrieved: list[tuple]) -> str:
    """A no-API-key fallback: returns the most relevant excerpts directly,
    labeled by source, instead of an LLM-generated synthesis.

    This keeps the demo runnable end-to-end without requiring an API key,
    while preserving the same grounding guarantee -- every line shown is
    verbatim from a source, so there's nothing to hallucinate.
    """
    lines = ["(No ANTHROPIC_API_KEY set -- showing the most relevant raw excerpts instead of a generated synthesis.)\n"]
    for i, (chunk, score) in enumerate(retrieved, start=1):
        snippet = chunk.text[:400].rsplit(" ", 1)[0] + ("..." if len(chunk.text) > 400 else "")
        lines.append(f"(Source {i}: {chunk.source_title}, relevance {score:.2f})\n{snippet}\n")
    return "\n".join(lines)


def answer_question(index: VectorIndex, question: str, top_k: int = 5, min_similarity: float = 0.08) -> str:
    retrieved = index.query(question, top_k=top_k, min_similarity=min_similarity)

    if not retrieved:
        return REFUSAL_MESSAGE

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        return _extractive_fallback(question, retrieved)

    import anthropic

    client = anthropic.Anthropic(api_key=api_key)
    prompt = build_grounded_prompt(question, retrieved)

    response = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=800,
        messages=[{"role": "user", "content": prompt}],
    )
    return "".join(block.text for block in response.content if block.type == "text")


def generate_brief(index: VectorIndex) -> str:
    """Runs a fixed set of questions that together make up a content brief,
    and stitches the answers into a single structured document.
    """
    sections = {
        "Shared subtopics": "What subtopics or sections do most of these articles cover in common?",
        "Suggested structure": "What is the most common structure or outline these articles follow?",
        "Gap opportunities": "What relevant subtopics does only one article cover, or none of them cover well?",
        "Headline patterns": "What kind of headlines or titles do these articles use?",
    }

    brief_parts = ["# Content Brief\n"]
    for heading, question in sections.items():
        answer = answer_question(index, question)
        brief_parts.append(f"## {heading}\n{answer}\n")

    return "\n".join(brief_parts)
