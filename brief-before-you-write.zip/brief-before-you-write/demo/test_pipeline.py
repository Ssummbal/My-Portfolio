"""Quick smoke test -- not a full test suite, just verifies the pipeline runs end to end."""

from ingest import Source, VectorIndex
from query import answer_question, generate_brief

sources = [
    Source(
        title="Article A: Beginner's Guide to Sourdough",
        text=(
            "Sourdough bread relies on a natural starter instead of commercial yeast. "
            "To make a starter, mix equal parts flour and water and let it ferment for five to seven days, "
            "feeding it daily. Once active, the starter is mixed with flour, water, and salt to form a dough. "
            "The dough undergoes a series of stretch and folds over several hours, known as bulk fermentation. "
            "After bulk fermentation, the dough is shaped and left to proof, often overnight in the refrigerator. "
            "Finally, the loaf is scored and baked in a very hot oven, often inside a Dutch oven to trap steam."
        ),
    ),
    Source(
        title="Article B: Why Your Sourdough Isn't Rising",
        text=(
            "A common issue for beginner bakers is a starter that isn't active enough before baking. "
            "The starter should double in size within four to six hours of feeding and pass the float test. "
            "Under-proofed dough will be dense, while over-proofed dough can collapse when scored. "
            "Temperature also plays a large role: a warmer kitchen speeds up fermentation significantly. "
            "Using a kitchen scale instead of volume measurements is recommended for consistent hydration."
        ),
    ),
    Source(
        title="Article C: Sourdough Baking Equipment Guide",
        text=(
            "A Dutch oven is the most commonly recommended baking vessel because it traps steam, "
            "producing a crackly crust. A bench scraper helps handle sticky dough during shaping. "
            "A kitchen scale ensures accurate flour and water ratios, which is critical for hydration consistency. "
            "A bread lame or sharp razor is used for scoring the loaf before baking to control how it expands."
        ),
    ),
]

index = VectorIndex()
index.build(sources)
print(f"Built index with {len(index.chunks)} chunks from {len(sources)} sources.\n")

print("=== Q&A test ===")
q = "What tools do these articles recommend for baking sourdough?"
print(f"Q: {q}")
print(answer_question(index, q))

print("\n=== Refusal test (question not covered by sources) ===")
q2 = "What's the best way to make a chocolate cake?"
print(f"Q: {q2}")
print(answer_question(index, q2))

print("\n=== Full brief generation ===")
print(generate_brief(index))
