"""
app.py

Minimal Streamlit interface for the demo. Not meant to be production
UI -- just enough to show the end-to-end flow: paste sources, ask
questions or generate a full brief, see grounded answers with citations.

Run with: streamlit run app.py
"""

import streamlit as st
from ingest import Source, VectorIndex, fetch_article_text
from query import answer_question, generate_brief

st.set_page_config(page_title="Brief Before You Write", page_icon="📝")
st.title("📝 Brief Before You Write")
st.caption("Turn competitor articles into a grounded content brief -- with citations for every claim.")

if "index" not in st.session_state:
    st.session_state.index = None
    st.session_state.sources = []

st.subheader("1. Add source articles")
st.write("Add 3-5 competitor articles for the same target keyword, as URLs or pasted text.")

num_sources = st.number_input("How many sources?", min_value=1, max_value=5, value=3)

sources_input = []
for i in range(num_sources):
    with st.expander(f"Source {i + 1}", expanded=(i == 0)):
        mode = st.radio(f"Input type for source {i + 1}", ["Paste text", "URL"], key=f"mode_{i}", horizontal=True)
        title = st.text_input(f"Title / label for source {i + 1}", key=f"title_{i}", value=f"Article {i + 1}")
        if mode == "URL":
            url = st.text_input(f"URL for source {i + 1}", key=f"url_{i}")
            sources_input.append(("url", title, url))
        else:
            text = st.text_area(f"Paste article text for source {i + 1}", key=f"text_{i}", height=150)
            sources_input.append(("text", title, text))

if st.button("Build index from these sources", type="primary"):
    sources = []
    errors = []
    for mode, title, value in sources_input:
        if not value:
            continue
        if mode == "url":
            try:
                text = fetch_article_text(value)
                sources.append(Source(title=title, text=text, url=value))
            except Exception as e:
                errors.append(f"Couldn't fetch {value}: {e}")
        else:
            sources.append(Source(title=title, text=value))

    if errors:
        for e in errors:
            st.warning(e)

    if sources:
        index = VectorIndex()
        try:
            index.build(sources)
            st.session_state.index = index
            st.session_state.sources = sources
            st.success(f"Index built from {len(sources)} source(s), {len(index.chunks)} chunks total.")
        except ValueError as e:
            st.error(str(e))
    else:
        st.error("No usable sources provided.")

st.divider()

if st.session_state.index:
    st.subheader("2. Ask a question or generate a full brief")

    tab1, tab2 = st.tabs(["Ask a question", "Generate full brief"])

    with tab1:
        question = st.text_input("Ask something about your sources, e.g. 'what's missing that I could add?'")
        if st.button("Get grounded answer"):
            with st.spinner("Retrieving and answering..."):
                answer = answer_question(st.session_state.index, question)
            st.markdown(answer)

    with tab2:
        if st.button("Generate content brief"):
            with st.spinner("Building brief from all sources..."):
                brief = generate_brief(st.session_state.index)
            st.markdown(brief)
            st.download_button("Download brief as Markdown", brief, file_name="content_brief.md")
else:
    st.info("Build an index from your sources above to get started.")
