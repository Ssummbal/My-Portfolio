"""
ingest.py

Handles turning raw source articles (pasted text or URLs) into a searchable
index of chunks. This is the retrieval half of the RAG pipeline.

Design notes:
- Uses TF-IDF vectors instead of a neural embedding model. This keeps the
  demo dependency-light (no large model downloads) while still giving
  meaningful similarity search over article-length text. Swapping in a
  proper embedding model (e.g. sentence-transformers, OpenAI embeddings)
  is a drop-in replacement -- see `VectorIndex` below.
- Every chunk keeps a reference back to its source article, because the
  whole point of this tool is that every claim must be traceable to a
  specific source (see decision-rule.md).
"""

from __future__ import annotations

import re
import requests
from dataclasses import dataclass, field
from bs4 import BeautifulSoup
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


@dataclass
class Chunk:
    text: str
    source_title: str
    source_id: int
    chunk_id: int


@dataclass
class Source:
    title: str
    text: str
    url: str | None = None


def fetch_article_text(url: str) -> str:
    """Fetch a URL and strip it down to (approximate) main article text.

    This is intentionally simple -- a production version would use a
    proper readability extractor. For source articles that block scraping
    or are paywalled, the tool falls back to manual paste (see app.py).
    """
    resp = requests.get(url, timeout=10, headers={"User-Agent": "Mozilla/5.0"})
    resp.raise_for_status()
    soup = BeautifulSoup(resp.text, "html.parser")

    for tag in soup(["script", "style", "nav", "header", "footer", "aside"]):
        tag.decompose()

    paragraphs = [p.get_text(" ", strip=True) for p in soup.find_all("p")]
    text = "\n".join(p for p in paragraphs if len(p.split()) > 5)
    return text


def chunk_text(text: str, target_words: int = 350, overlap_words: int = 50) -> list[str]:
    """Split text into overlapping word-count chunks.

    Overlap prevents a relevant sentence from being split awkwardly across
    two chunks and lost to both during retrieval.
    """
    words = re.sub(r"\s+", " ", text).strip().split(" ")
    if not words:
        return []

    chunks = []
    start = 0
    while start < len(words):
        end = min(start + target_words, len(words))
        chunk = " ".join(words[start:end])
        if chunk.strip():
            chunks.append(chunk)
        if end == len(words):
            break
        start = end - overlap_words
    return chunks


class VectorIndex:
    """A minimal TF-IDF-backed similarity index over chunks.

    Methods mirror what you'd expect from a real vector store (Chroma,
    FAISS, etc.) so this class can be swapped out without changing the
    rest of the pipeline.
    """

    def __init__(self):
        self.chunks: list[Chunk] = []
        self._vectorizer: TfidfVectorizer | None = None
        self._matrix = None

    def build(self, sources: list[Source], target_words: int = 350, overlap_words: int = 50):
        self.chunks = []
        for source_id, source in enumerate(sources):
            pieces = chunk_text(source.text, target_words, overlap_words)
            for chunk_id, piece in enumerate(pieces):
                self.chunks.append(
                    Chunk(text=piece, source_title=source.title, source_id=source_id, chunk_id=chunk_id)
                )

        if not self.chunks:
            raise ValueError("No chunks produced -- check that source articles have usable text.")

        self._vectorizer = TfidfVectorizer(stop_words="english", max_features=5000)
        self._matrix = self._vectorizer.fit_transform([c.text for c in self.chunks])

    def query(self, question: str, top_k: int = 5, min_similarity: float = 0.08):
        """Return the top_k most relevant chunks for a question.

        min_similarity is the gate referenced in decision-rule.md: if
        nothing clears this bar, the caller should treat the question as
        unanswerable from the provided sources rather than forcing an
        answer from the best-available (but irrelevant) chunk.
        """
        if self._vectorizer is None:
            raise RuntimeError("Index not built yet -- call .build() first.")

        q_vec = self._vectorizer.transform([question])
        sims = cosine_similarity(q_vec, self._matrix)[0]

        ranked = sorted(zip(self.chunks, sims), key=lambda x: x[1], reverse=True)
        results = [(chunk, float(score)) for chunk, score in ranked[:top_k] if score >= min_similarity]
        return results
