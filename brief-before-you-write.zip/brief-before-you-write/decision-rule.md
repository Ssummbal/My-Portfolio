# Decision Rule: Grounding vs. Fluency

This document explains the single most important product decision in Brief Before You Write, and why it was designed this way on purpose.

## The tension

Ask a general-purpose LLM "what's a good content structure for an article about sourdough baking" and it will give you a fluent, plausible-sounding answer, drawn from everything it learned during training. That answer might even be *correct*. But it has nothing to do with the specific competitor articles the user actually cares about.

For this tool, that's a failure, not a feature. The entire value of Brief Before You Write is that it tells you what *your specific competitors* are doing, not what's generically true about the topic. If it starts blending in outside knowledge, the user can no longer trust that a suggestion in the brief reflects real competitive research versus the model's own guess.

## The rule

The system follows one rule, enforced at two points in the pipeline:

1. **Retrieve before generating, every time.** No question is ever sent to the language model without first attaching the actual retrieved source excerpts. The model is explicitly instructed to answer only from those excerpts.
2. **Refuse when retrieval comes up empty.** If no chunk in the source articles clears a minimum relevance threshold for the question being asked, the system does not attempt an answer. It says plainly that the sources don't cover it (`REFUSAL_MESSAGE` in `query.py`).

This means the tool will sometimes say "I can't determine that from your sources" in a case where a general-purpose LLM would have guessed correctly from training data. That's an intentional cost, not a bug. A wrong-but-confident content brief is worse than an honest "not covered," because the whole premise of the tool is that the user should be able to trust what it tells them about their specific competitors.

## Where the threshold lives

The gate is the `min_similarity` parameter in `ingest.VectorIndex.query()` (default `0.08` for the TF-IDF-based demo index). Any retrieved chunk scoring below this is discarded entirely before generation. If *nothing* clears it, `query.answer_question()` returns the refusal message instead of calling the model at all.

This threshold is dataset-dependent. TF-IDF similarity scores compress toward zero as vocabulary size and chunk count grow, so a value tuned on a 3-article demo will not necessarily transfer cleanly to a 10-article, more topically diverse set of sources. In a production version, this would need calibration against a labeled test set (known-answerable vs. known-unanswerable questions) rather than a single hardcoded constant — flagged as an open question in the PRD.

## Why TF-IDF instead of a neural embedding model

The demo uses TF-IDF + cosine similarity rather than a neural embedding model (e.g. sentence-transformers or an API-based embedding). This was a deliberate scope decision for a portfolio build:

- No large model download or GPU dependency — the whole pipeline runs in a lightweight environment.
- TF-IDF is transparent: it's straightforward to reason about *why* a chunk was or wasn't retrieved, which matters for a tool whose entire pitch is trustworthy retrieval.
- The tradeoff: TF-IDF matches on lexical overlap, not semantic meaning. A question phrased very differently from the source wording (e.g. "how do I stop my bread from collapsing" vs. a source that only says "over-proofed dough") may under-retrieve.

`ingest.VectorIndex` is written so this is a contained swap: replacing the `TfidfVectorizer`/`cosine_similarity` calls with a neural embedding model and a proper vector store (Chroma, FAISS, etc.) doesn't require changing `query.py` or `app.py` at all — the class's public interface (`build()`, `query()`) stays the same.

## Same pattern as my other case studies

This is the same underlying design question as **Where the Chatbot Has to Stop**: deciding exactly where an AI system's confidence runs out and it must hand off, rather than push through with a fluent-but-unfounded answer. Here, the "handoff" isn't to a human agent, it's to an honest admission that the source material doesn't say what the user is asking.
