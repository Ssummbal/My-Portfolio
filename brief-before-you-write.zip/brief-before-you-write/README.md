# 📝 Brief Before You Write

A RAG-powered assistant that turns a handful of top-ranking competitor articles into a grounded, citation-backed content brief — built for freelance SEO writers who don't have time to manually cross-reference five articles before every piece.

> I built this because I needed it myself. As a freelance SEO content writer, the "research the top-ranking articles" step is the most valuable and most-skipped part of the process. This tool does that research for you, without inventing anything that isn't actually in your sources.

**[Watch the demo →]** *(add your Loom/GIF link here)*

---

## The problem

Before writing an SEO article, you're supposed to check what's already ranking, spot the gaps, and structure your piece around search intent. In practice, this step is manual, slow, and inconsistent — most writers either skip it or do a shallow pass.

## The product

You give it 3-5 competitor articles (URLs or pasted text). It:
- Chunks and indexes the content
- Answers direct questions ("what's missing that I could add?")
- Generates a full structured brief: shared subtopics, common structure, gap opportunities, headline patterns
- **Cites every claim back to a specific source article**
- **Explicitly refuses to answer** if the question isn't actually covered by your sources, instead of guessing from general knowledge

See [`decision-rule.md`](./decision-rule.md) for why that refusal behavior is the whole point of this tool.

## Why this is a RAG problem (not just "ask an LLM")

A general-purpose LLM will happily generate a plausible-sounding content brief from its training data. That's the opposite of useful here — the value is entirely in *your specific competitors' articles*, not generic SEO advice. Retrieval-augmented generation is what lets the system answer only from what's actually in front of it, with receipts.

## Tech stack (demo build)

- **Retrieval:** TF-IDF vectorization + cosine similarity ([scikit-learn](https://scikit-learn.org)) — kept intentionally lightweight for a portfolio demo; see [`decision-rule.md`](./decision-rule.md) for the tradeoff and how to swap in a neural embedding model instead.
- **Generation:** Anthropic Claude (via API key), with an extractive fallback that shows raw cited excerpts if no API key is set — the tool is fully runnable with zero API cost.
- **Scraping:** `requests` + `BeautifulSoup` for URL sources; manual paste supported as a fallback for paywalled sources.
- **Interface:** Streamlit, for a minimal working demo.

## Running it

```bash
cd demo
pip install -r requirements.txt

# Optional: set this to get LLM-synthesized answers instead of raw excerpts
export ANTHROPIC_API_KEY=your_key_here

streamlit run app.py
```

Or run the non-UI smoke test to see the pipeline end-to-end in the terminal:

```bash
cd demo
python test_pipeline.py
```

## Repo structure

```
brief-before-you-write/
├── README.md              # This file
├── PRD.md                 # Full product requirements document
├── decision-rule.md        # The grounding/refusal logic, explained
├── demo/
│   ├── ingest.py           # Scraping + chunking + indexing
│   ├── query.py            # Retrieval + grounded generation + refusal logic
│   ├── app.py              # Streamlit demo interface
│   ├── test_pipeline.py    # End-to-end smoke test
│   └── requirements.txt
└── examples/
    └── sample_brief_output.md
```

## Part of a broader AI product portfolio

This is one of several AI product case studies I've built while transitioning into AI Product Management, each centered on the same underlying question: where should an AI system draw the line between being helpful and staying honest about what it doesn't know.

- **Verify Before You Wire** — a risk-scoring layer for deepfake wire fraud
- **Where the Chatbot Has to Stop** — an escalation rule for when AI must hand off to a human
- **Where the Editing Workflow Draws the Line** — separating AI-safe tasks from human-judgment tasks in content production
- **SIM Continuity Guard** — pre-issuance risk scoring for recycled phone numbers
- **Brief Before You Write** *(this repo)* — grounded content research via RAG
