# Verify Before You Wire

![Verify Before You Wire](./assets/cover.png)

**An explainable AI risk-verification layer that stops deepfake voice and video impersonation fraud from reaching a wire transfer or payment change.**

*AI Product Management case study by wajiha — open to remote AI PM work in trust & safety and fraud-risk products.*

**[Live prototype →](https://YOUR-USERNAME.github.io/verify-before-you-wire/prototype/)** · [Full case study (PDF)](./case-study.pdf)

---

## The problem

In January 2024, a finance employee at engineering firm Arup joined a video call with five colleagues and authorized 15 wire transfers totaling $25.6M. Every other participant on that call was an AI-generated deepfake. Ferrari, WPP, LastPass, and Wiz each faced the same style of attack that year — a cloned executive voice requesting an urgent payment — and all four caught it. Not with software. Because an employee happened to ask an unscripted question the deepfake couldn't answer.

Deepfake-enabled voice phishing rose roughly 1,600% in a single quarter (Q4 2024 → Q1 2025). Average confirmed loss per incident exceeds $280,000. Deloitte projects AI-enabled fraud could reach $40B/year by 2027.

## The idea

Real-time deepfake detection is an arms race against generation models that improve every quarter. The pattern above suggests a more durable fix: instead of trying to spot an increasingly convincing fake, route every high-value approval through a channel a deepfake can't reach — scaled to how risky the request looks.

**Approval Integrity Score** — every wire transfer or payment-detail change is scored in real time on:
- Channel consistency (pre-registered vs. new/unverified)
- Payee/account novelty
- Request media risk (live video/voice vs. authenticated system)
- Urgency/pressure language
- Deviation from the requester's normal approval pattern

| Score | Band | Action |
|---|---|---|
| 0–39 | Low risk | Proceeds normally, no added friction |
| 40–69 | Medium risk | Automatic out-of-band callback via a pre-registered secondary channel |
| 70–100 | High risk | Held for dual human authorization + a live, unscripted verification question |

## How it works

![Approval verification procedure — a high-value request is scored on five signals, routed to a risk band, and put through that band's own verification step, ending in funds released or held for fraud team review](./assets/procedure-flow.png)

## What's in the full case study

Problem framing and named 2024 incidents · why this is a board-level issue, not just a security one · personas · illustrative opportunity sizing · the scoring model and data approach · the approval flow · success metrics (including guardrails against over-friction) · a phased rollout plan · risks and ethical trade-offs (privacy, false sense of security, adversarial adaptation).

[Read the full case study →](./case-study.pdf)

## Prototype

`/prototype` is a single self-contained HTML file — no build step, no dependencies. Open `index.html` directly in a browser, or visit the live link above. Adjust the request signals and the score, risk band, recommended action, and explainable reason codes update live.

## Why this design, not another deepfake detector

Detection tools (Pindrop, Reality Defender, and similar) analyze the audio/video itself for signs it's synthetic — valuable, and genuinely hard technology. But none of the documented saves above were made by a detector. They were made by a verification step outside the deepfake's reach. This project leans into that finding: a risk-scoring layer that stays effective regardless of how convincing the underlying fake becomes, because it isn't trying to answer "is this real" at all.

---

*Self-directed portfolio case study, not a commissioned engagement — built to demonstrate AI product thinking from problem framing through to a working prototype.*
